-- Station 1

DROP DATABASE IF EXISTS station1_db;
CREATE DATABASE station1_db;

-- Station 2

DROP DATABASE IF EXISTS station2_db;
CREATE DATABASE station2_db;

-- Station 3

DROP DATABASE IF EXISTS station3_db;
CREATE DATABASE station3_db;

-- Central

DROP DATABASE IF EXISTS central_db;
CREATE DATABASE central_db;