package via.pro3.station_server_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StationServer3Application {

    public static void main(String[] args) {
        SpringApplication.run(StationServer3Application.class, args);
    }

}
