package via.pro3.station_server_3.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "half_animal")
public class HalfAnimal extends Product{
}