package via.pro3.station_server_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest class StationServer2ApplicationTests
{

  @Test void contextLoads()
  {
  }

}
