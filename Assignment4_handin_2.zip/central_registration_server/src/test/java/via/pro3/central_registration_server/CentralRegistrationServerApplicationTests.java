package via.pro3.central_registration_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest class CentralRegistrationServerApplicationTests
{

  @Test void contextLoads()
  {
  }

}
