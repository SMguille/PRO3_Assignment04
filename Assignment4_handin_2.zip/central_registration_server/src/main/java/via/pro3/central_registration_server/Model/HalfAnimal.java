package via.pro3.central_registration_server.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "half_animal") 
public class HalfAnimal extends Product{
}