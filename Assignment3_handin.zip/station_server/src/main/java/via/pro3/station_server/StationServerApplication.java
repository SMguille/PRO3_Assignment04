package via.pro3.station_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication public class StationServerApplication
{

  public static void main(String[] args)
  {
    SpringApplication.run(StationServerApplication.class, args);
  }

}
