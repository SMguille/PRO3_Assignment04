package via.pro3.central_registration_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication public class CentralRegistrationServerApplication
{

  public static void main(String[] args)
  {
    SpringApplication.run(CentralRegistrationServerApplication.class, args);
  }

}
