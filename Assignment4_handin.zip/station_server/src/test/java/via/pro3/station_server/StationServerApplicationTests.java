package via.pro3.station_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest class StationServerApplicationTests
{

  @Test void contextLoads()
  {
  }

}
