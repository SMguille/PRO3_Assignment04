package via.pro3.station_server_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication public class StationServer2Application
{

  public static void main(String[] args)
  {
    SpringApplication.run(StationServer2Application.class, args);
  }

}
