DROP SCHEMA IF EXISTS pro3_assignment_station CASCADE;
CREATE SCHEMA pro3_assignment_station;
SET SCHEMA 'pro3_assignment_station';

-- Station 1

-- Station 2

-- Station 3